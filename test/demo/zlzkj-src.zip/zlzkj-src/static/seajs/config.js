var version = "1.0";
seajs.config({
	alias: {
		"form": "mod/jquery/jquery.form",
		"dialog": "mod/dialog/dialog.js",
		"flexslider": "mod/flexslider/flexslider.js",
		"nprogress": "mod/nprogress/nprogress.js",
		"scrollspy": "mod/jquery/scrollspy",
		'baidumap': 'http://api.map.baidu.com/getscript?v=2.0&ak=C3ef7404a7f457abebb032ff9b1af4eb'
	},
	paths: {
		"js": "app/js",
        "css": "app/css",
        "jquery": "app/jquery",
        "fancybox": "mod/fancybox/"
	},
	map: [
		[ /^(.*\.(?:css|js))(.*)$/i, '$1?v='+version ]
	]
});


